<?php
    defined('_JEXEC') or die;

    // Include the syndicate functions only once
    require_once __DIR__ . '/helper.php';

    echo ModMenuHelper::getMplc();
